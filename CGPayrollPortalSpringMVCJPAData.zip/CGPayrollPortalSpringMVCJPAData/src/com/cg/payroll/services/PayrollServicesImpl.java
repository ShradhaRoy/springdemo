package com.cg.payroll.services;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.cg.payroll.beans.Associate;
import com.cg.payroll.beans.BankDetails;
import com.cg.payroll.beans.Salary;
import com.cg.payroll.daoservices.AssociateDAO;
import com.cg.payroll.exceptions.AssociateDetailsNotFoundException;
@Component("payrollServices")
public class PayrollServicesImpl implements PayrollServices{
@Autowired
	private AssociateDAO  associateDao;

	@Override
	public int acceptAssociateDetails(String firstName, String lastName, String emailId, String department,
			String designation, String pancard, int yearlyInvestmentUnder80C, int basicSalary, int epf, int companyPf,
			int accountNumber,String bankName, String ifscCode) {
	Associate associate = new Associate( yearlyInvestmentUnder80C, firstName, lastName, department, designation, pancard, emailId, 
			                             new Salary(basicSalary, epf, companyPf), new BankDetails(accountNumber, bankName, ifscCode));
	associate = associateDao.save(associate);
		return associate.getAssociateId();
	}
	@Override
	public double calculateNetSalary(int associateId) throws AssociateDetailsNotFoundException {
		Associate associate = getAssociateDetails(associateId);
		associate.getSalary().setNetSalary((int) (12*calculateGrossSalary(associateId)+associate.getSalary().getCompanyPf()+associate.getSalary().getEpf()));
		associateDao.save(associate);
		return associate.getSalary().getNetSalary();
//		return 12*calculateGrossSalary(associateId)+associate.getSalary().getCompanyPf()+associate.getSalary().getEpf();
	}
	@Override
	public Associate getAssociateDetails(int associateId) throws AssociateDetailsNotFoundException {
		return associateDao.findById(associateId).orElseThrow(()->new AssociateDetailsNotFoundException("Associate Details Not Found"));
		
	}
	@Override
	public List<Associate> getAllAssociateDetails() {
		
		return associateDao.findAll();
	}
	@Override
	public double calculateGrossSalary(int associateId)throws AssociateDetailsNotFoundException{
		Associate associate = getAssociateDetails(associateId);
		associate.getSalary().setGrossSalary ((int) (associate.getSalary().getBasicSalary()
				+0.3*associate.getSalary().getBasicSalary()*2
				+0.25*associate.getSalary().getBasicSalary()
				+0.2*associate.getSalary().getBasicSalary()
				+associate.getSalary().getCompanyPf()
				+associate.getSalary().getEpf()));
		
		associateDao.save(associate);
		return associate.getSalary().getGrossSalary();
		/*
		 * return (associate.getSalary().getBasicSalary()
		 * +0.3*associate.getSalary().getBasicSalary()*2
		 * +0.25*associate.getSalary().getBasicSalary()
		 * +0.2*associate.getSalary().getBasicSalary()
		 * +associate.getSalary().getCompanyPf() +associate.getSalary().getEpf());
		 */
	}
}
